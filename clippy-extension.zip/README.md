Clippy chrome extension
=====